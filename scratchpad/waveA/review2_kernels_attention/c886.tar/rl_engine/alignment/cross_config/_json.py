# SPDX-License-Identifier: Apache-2.0
"""Compatibility import; the canonical module is loaded below."""

import importlib
import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

if __name__ == "__main__":
    import runpy

    runpy.run_module("rl_engine.validation.cross_config._json", run_name="__main__")
else:
    sys.modules[__name__] = importlib.import_module("rl_engine.validation.cross_config._json")

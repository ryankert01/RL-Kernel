from __future__ import annotations

import os
import pathlib
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import torch

from rl_engine.contracts.operators.logprob import (
    LogprobContract,
    LogprobDType,
    LogprobRole,
    MaskSpec,
    ReductionSpec,
    ShardingSpec,
)
from rl_engine.reference.logprob.vocab_parallel_logp import DEFAULT_NUM_VOCAB_TILES
from rl_engine.runtime.plan import operator_ablation_case

_ALIGNMENT_DIAGNOSTIC_LOCK = threading.Lock()
_ALIGNMENT_DIAGNOSTIC_CALLS = 0


class _SparseTpSum(torch.autograd.Function):
    """Sum disjoint vocabulary-owner values without duplicating gradients.

    Every sparse nucleus ID belongs to exactly one TP rank, so the forward
    collective combines one non-zero value with zeros.  The replicated loss
    is evaluated on every TP rank; its backward therefore passes the local
    gradient through without a second cross-rank sum.
    """

    @staticmethod
    def forward(ctx: Any, values: torch.Tensor, group: Any) -> torch.Tensor:
        ctx.group = group
        result = values.clone()
        if group is not None and torch.distributed.get_world_size(group=group) > 1:
            torch.distributed.all_reduce(result, group=group)
        return result

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None]:
        return grad_output, None


class _HipSparseNucleusLogp(torch.autograd.Function):
    """Use one pre-built HIP code object in rollout and training processes."""

    @staticmethod
    def forward(
        ctx: Any,
        logits: torch.Tensor,
        ids: torch.Tensor,
        valid: torch.Tensor,
        targets: torch.Tensor,
        inverse_temperature: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        from rl_engine.backends.extension import _C

        result, lse, entropy = _C.hip_sparse_nucleus_logp_forward(
            logits, ids, valid, targets, inverse_temperature
        )
        ctx.save_for_backward(logits, ids, valid, targets, inverse_temperature, lse)
        ctx.mark_non_differentiable(entropy)
        return result, lse, entropy

    @staticmethod
    def backward(
        ctx: Any,
        grad_result: torch.Tensor | None,
        grad_lse: torch.Tensor | None,
        grad_entropy: torch.Tensor | None,
    ) -> tuple[torch.Tensor, None, None, None, None]:
        from rl_engine.backends.extension import _C

        logits, ids, valid, targets, inverse_temperature, lse = ctx.saved_tensors
        if grad_result is None:
            grad_result = torch.zeros_like(lse)
        if grad_lse is None:
            grad_lse = torch.zeros_like(lse)
        grad_logits = _C.hip_sparse_nucleus_logp_backward(
            logits,
            ids,
            valid,
            targets,
            inverse_temperature,
            lse,
            grad_result.float().contiguous(),
            grad_lse.float().contiguous(),
        )
        return grad_logits, None, None, None, None


def _alignment_diagnostics_enabled() -> bool:
    return os.getenv("RL_KERNEL_ALIGNMENT_DIAGNOSTICS", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _alignment_diagnostic_rank() -> int:
    try:
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            return int(torch.distributed.get_rank())
    except (RuntimeError, ValueError):
        pass
    try:
        return int(os.getenv("RANK", "0"))
    except ValueError:
        return 0


def _alignment_tensor_summary(value: torch.Tensor) -> dict[str, Any]:
    detached = value.detach()
    flat = detached.reshape(-1)
    first = flat[:16].to(device="cpu")
    last = flat[-16:].to(device="cpu") if flat.numel() else first
    summary: dict[str, Any] = {
        "shape": list(detached.shape),
        "dtype": str(detached.dtype).replace("torch.", ""),
        "device": str(detached.device),
        "first16": first.tolist(),
        "last16": last.tolist(),
    }
    if detached.numel():
        values = detached.float()
        summary.update(
            {
                "sum_fp32": float(values.sum().item()),
                "abs_sum_fp32": float(values.abs().sum().item()),
                "min_fp32": float(values.min().item()),
                "max_fp32": float(values.max().item()),
            }
        )
    return summary


def _record_alignment_diagnostics(
    *,
    target: str,
    local_logits: torch.Tensor,
    target_ids: torch.Tensor,
    result: torch.Tensor,
    lse: torch.Tensor,
    vocab_start_index: int,
    hidden: torch.Tensor | None = None,
    lm_head_weight: torch.Tensor | None = None,
) -> None:
    """Persist bounded row diagnostics only when explicitly enabled.

    This branch performs device-to-host copies and reductions for debugging;
    production runs leave it cold and do no additional tensor work.
    """

    if not _alignment_diagnostics_enabled():
        return
    root = os.getenv("RL_KERNEL_ALIGNMENT_DIAGNOSTICS_DIR", "").strip()
    if not root:
        return
    global _ALIGNMENT_DIAGNOSTIC_CALLS
    with _ALIGNMENT_DIAGNOSTIC_LOCK:
        call_index = _ALIGNMENT_DIAGNOSTIC_CALLS
        _ALIGNMENT_DIAGNOSTIC_CALLS += 1
    detached_logits = local_logits.detach()
    ids = target_ids.detach().to(device="cpu", dtype=torch.int64)
    local_ids = target_ids.detach().to(dtype=torch.long) - int(vocab_start_index)
    local_mask = (local_ids >= 0) & (local_ids < detached_logits.size(1))
    safe_ids = local_ids.clamp(0, max(int(detached_logits.size(1)) - 1, 0))
    selected_local = detached_logits.gather(1, safe_ids.reshape(-1, 1)).reshape(-1)
    selected_local = torch.where(
        local_mask,
        selected_local,
        torch.full_like(selected_local, float("nan")),
    )
    row_sum = detached_logits.float().sum(dim=1)
    row_abs_sum = detached_logits.float().abs().sum(dim=1)
    payload = {
        "schema_version": "rlkernel.linear_logp_alignment_diagnostic.v1",
        "target": target,
        "rank": _alignment_diagnostic_rank(),
        "pid": os.getpid(),
        "call_index": call_index,
        "vocab_start_index": int(vocab_start_index),
        "target_ids": ids,
        "selected_local_logits": selected_local.cpu(),
        "result": result.detach().cpu(),
        "lse": lse.detach().cpu(),
        "row_sum_fp32": row_sum.cpu(),
        "row_abs_sum_fp32": row_abs_sum.cpu(),
        "logits_head": detached_logits[:, :8].cpu(),
        "logits_tail": detached_logits[:, -8:].cpu(),
        "logits_summary": _alignment_tensor_summary(detached_logits),
    }
    if hidden is not None:
        payload["hidden"] = hidden.detach().cpu()
        payload["hidden_summary"] = _alignment_tensor_summary(hidden)
    if lm_head_weight is not None:
        detached_weight = lm_head_weight.detach()
        payload["lm_head_weight_head"] = detached_weight[:8].cpu()
        payload["lm_head_weight_tail"] = detached_weight[-8:].cpu()
        payload["lm_head_weight_summary"] = _alignment_tensor_summary(detached_weight)
    output_dir = pathlib.Path(root)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / (
        f"{target}-pid{os.getpid()}-rank{_alignment_diagnostic_rank():05d}-"
        f"call{call_index:08d}.pt"
    )
    torch.save(payload, path)


@dataclass(frozen=True)
class RolloutLinearLogpContext:
    """The exact hidden/LM-head contract for the immediately following sample."""

    hidden: torch.Tensor
    lm_head_weight: torch.Tensor
    lm_head_bias: torch.Tensor | None
    tp_group: Any
    vocab_start_index: int
    global_vocab_size: int
    real_vocab_size: int


_ROLLOUT_CONTEXT: RolloutLinearLogpContext | None = None


def publish_rollout_linear_logp_context(
    hidden: torch.Tensor,
    lm_head_weight: torch.Tensor,
    lm_head_bias: torch.Tensor | None,
    *,
    tp_group: Any,
    vocab_start_index: int,
    global_vocab_size: int,
    real_vocab_size: int,
) -> None:
    """Publish one model-output context for the next vLLM sampler invocation."""

    global _ROLLOUT_CONTEXT
    if hidden.ndim != 2:
        raise ValueError(
            f"rollout linear_logp hidden must be [tokens, hidden], got {tuple(hidden.shape)}"
        )
    if lm_head_weight.ndim != 2:
        raise ValueError("rollout linear_logp LM-head weight must be [vocab_local, hidden]")
    if hidden.device != lm_head_weight.device:
        raise ValueError("rollout linear_logp hidden and LM-head must share a device")
    if hidden.size(1) != lm_head_weight.size(1):
        raise ValueError("rollout linear_logp hidden and LM-head hidden widths must match")
    if lm_head_bias is not None and (
        lm_head_bias.ndim != 1
        or lm_head_bias.size(0) != lm_head_weight.size(0)
        or lm_head_bias.device != hidden.device
    ):
        raise ValueError("rollout linear_logp bias must match the complete local LM-head shard")
    if int(global_vocab_size) <= 0 or int(real_vocab_size) <= 0:
        raise ValueError("rollout linear_logp vocab sizes must be positive")
    if int(real_vocab_size) > int(global_vocab_size):
        raise ValueError("rollout linear_logp real vocab cannot exceed padded global vocab")
    _ROLLOUT_CONTEXT = RolloutLinearLogpContext(
        hidden=hidden,
        lm_head_weight=lm_head_weight,
        lm_head_bias=lm_head_bias,
        tp_group=tp_group,
        vocab_start_index=int(vocab_start_index),
        global_vocab_size=int(global_vocab_size),
        real_vocab_size=int(real_vocab_size),
    )


def clear_rollout_linear_logp_context() -> None:
    """Discard a context when vLLM computes logits without sampling from them."""

    global _ROLLOUT_CONTEXT
    _ROLLOUT_CONTEXT = None


def take_rollout_linear_logp_context() -> RolloutLinearLogpContext:
    """Consume the context published by the matching ``compute_logits`` call."""

    global _ROLLOUT_CONTEXT
    context = _ROLLOUT_CONTEXT
    _ROLLOUT_CONTEXT = None
    if context is None:
        raise RuntimeError(
            "strict rollout linear_logp sampler has no matching hidden/LM-head context"
        )
    return context


class LinearLogpWrapper:
    """PR230 integration adapter for the existing TP-aware linear_logp op."""

    # This is deliberately a different backend from the existing high-
    # performance linear_logp op.  PR1 exposes these strict entry points
    # without changing the old registry route.
    backend_id = "rlkernel.linear_logp.bitwise.v1"

    def __init__(self) -> None:
        self._op: Any | None = None
        self._tp_op: Any | None = None
        self._rocm_op: Any | None = None
        self._rocm_linear: Any | None = None
        self._last_provenance: dict[str, Any] = {}

    @property
    def provenance(self) -> Mapping[str, Any]:
        return dict(self._last_provenance)

    def _resolve(self, *, tensor_parallel: bool) -> Any:
        if tensor_parallel and self._tp_op is not None:
            return self._tp_op
        if not tensor_parallel and self._op is not None:
            return self._op
        try:
            from rl_engine.backends.cuda.logprob.linear_logp import (
                sm90_deterministic_linear_logp,
                sm90_deterministic_linear_logp_tp,
            )
        except (ImportError, AttributeError) as exc:
            raise RuntimeError(
                "strict bitwise linear_logp requires PR1's separate "
                "sm90_deterministic_linear_logp entry points"
            ) from exc
        op = (
            sm90_deterministic_linear_logp_tp if tensor_parallel else sm90_deterministic_linear_logp
        )
        # This wrapper is the strict boundary. Fail closed if a refactor ever
        # swaps in the native/provider logp path under the same API.
        expected_name = (
            "sm90_deterministic_linear_logp_tp"
            if tensor_parallel
            else "sm90_deterministic_linear_logp"
        )
        if getattr(op, "__name__", "") != expected_name:
            raise RuntimeError(
                "strict linear_logp resolved a non-deterministic implementation: "
                f"{getattr(op, '__name__', op)!r}"
            )
        if tensor_parallel:
            self._tp_op = op
        else:
            self._op = op
        return op

    def _resolve_rocm(self) -> Any:
        if self._rocm_op is None:
            from rl_engine.backends.rocm.logprob.vocab_parallel_logp import (
                RocmVocabParallelLogprobOp,
            )

            self._rocm_op = RocmVocabParallelLogprobOp()
        return self._rocm_op

    def _resolve_rocm_linear(self) -> Any:
        if self._rocm_linear is None:
            from rl_engine.ops.gemm.det_gemm import DetGemmOp

            self._rocm_linear = DetGemmOp()
        return self._rocm_linear

    @staticmethod
    def _tp_coordinates(tp_group: Any) -> tuple[int, int]:
        if tp_group is None:
            return 0, 1
        if not torch.distributed.is_available() or not torch.distributed.is_initialized():
            raise RuntimeError("strict TP linear_logp requires initialized torch.distributed")
        return (
            int(torch.distributed.get_rank(group=tp_group)),
            int(torch.distributed.get_world_size(group=tp_group)),
        )

    @staticmethod
    def _temperature_tensor(
        temperature: float | torch.Tensor | None, *, rows: int, device: torch.device
    ) -> torch.Tensor | None:
        if temperature is None:
            return None
        if isinstance(temperature, torch.Tensor):
            value = temperature.to(device=device, dtype=torch.float32).reshape(-1)
            if value.numel() == 1:
                value = value.expand(rows).contiguous()
            elif value.numel() == rows:
                value = value.contiguous()
            else:
                raise ValueError(
                    f"temperature must be scalar or one value per row, got {value.numel()}"
                )
            positive = torch.all(value > 0)
            if positive.is_cuda:
                torch._assert_async(positive, "temperature must be positive")
            elif not bool(positive):
                raise ValueError("temperature must be positive")
            return value
        scalar = float(temperature)
        if scalar <= 0.0:
            raise ValueError(f"temperature must be positive, got {scalar}")
        return torch.full((rows,), scalar, device=device, dtype=torch.float32)

    @staticmethod
    def _validate_targets(target_ids: torch.Tensor, *, rows: int, real_vocab_size: int) -> None:
        if target_ids.ndim != 1 or target_ids.numel() != rows:
            raise ValueError(
                f"linear_logp target_ids must be [rows]={rows}, got {tuple(target_ids.shape)}"
            )
        if target_ids.is_floating_point() or target_ids.is_complex():
            raise TypeError("linear_logp target_ids must use an integer dtype")
        if target_ids.numel():
            target_long = target_ids.to(dtype=torch.long)
            valid = torch.all((target_long >= 0) & (target_long < real_vocab_size))
            if valid.is_cuda:
                torch._assert_async(
                    valid,
                    f"linear_logp target_ids must be in [0, {real_vocab_size})",
                )
            elif not bool(valid):
                raise ValueError(
                    f"linear_logp target_ids must be in [0, {real_vocab_size}), got invalid ids"
                )

    def _canonical_sparse_nucleus_logp(
        self,
        gathered_logits: torch.Tensor,
        nucleus_ids: torch.Tensor,
        valid: torch.Tensor,
        target_ids: torch.Tensor,
        inverse_temperature: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Score a compact nucleus without launching one kernel per candidate."""

        columns = int(gathered_logits.size(1))
        # Keep the candidate axis fixed while leaving the independent row axis
        # dynamic.  Transcendentals below use explicit arithmetic polynomials,
        # avoiding the ROCm exp/log intrinsics whose low bits vary with the
        # calling execution context (vLLM graph versus Megatron eager).
        canonical_columns = int(os.getenv("RL_KERNEL_SPARSE_LOGP_CANONICAL_COLUMNS", "128"))
        if canonical_columns <= 0:
            raise ValueError("sparse logp canonical column count must be positive")
        if torch.version.hip is not None:
            canonical_columns = max(canonical_columns, columns)
        elif columns > canonical_columns:
            raise RuntimeError("CUDA sparse geometry exceeds configured columns")

        selected_present = torch.any(valid & (nucleus_ids == target_ids.reshape(-1, 1)), dim=1)
        torch._assert_async(
            torch.all(selected_present),
            "strict sparse top-p nucleus does not contain every target token",
        )

        if columns < canonical_columns:
            column_padding = canonical_columns - columns
            gathered_logits = torch.nn.functional.pad(
                gathered_logits, (0, column_padding), value=0.0
            )
            nucleus_ids = torch.nn.functional.pad(nucleus_ids, (0, column_padding), value=0)
            valid = torch.nn.functional.pad(valid, (0, column_padding), value=False)
        # ROCm must use the extension's already-compiled code object. A Triton
        # function may still specialize differently in independent processes.
        if torch.version.hip is None:
            raise RuntimeError("sparse nucleus HIP scorer requires ROCm")
        sparse_op = _HipSparseNucleusLogp
        return sparse_op.apply(
            gathered_logits,
            nucleus_ids,
            valid,
            target_ids,
            inverse_temperature,
        )

    def from_local_logits_sparse_nucleus(
        self,
        local_logits: torch.Tensor,
        target_ids: torch.Tensor,
        nucleus_ids: torch.Tensor,
        *,
        tp_group: Any,
        vocab_start_index: int,
        global_vocab_size: int,
        real_vocab_size: int,
        temperature: float | torch.Tensor | None,
        target: str,
        return_entropy: bool = False,
    ) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        """Score only retained top-p IDs while preserving the strict contract."""

        if local_logits.ndim != 2 or nucleus_ids.ndim != 2:
            raise ValueError("sparse top-p replay expects [T,V_local] logits and [T,K] IDs")
        if nucleus_ids.size(0) != local_logits.size(0):
            raise ValueError("sparse top-p nucleus rows must match local logits")
        if nucleus_ids.device != local_logits.device:
            raise ValueError("sparse top-p nucleus IDs must share the logits device")
        rank, world = self._tp_coordinates(tp_group)
        local_vocab = int(local_logits.size(1))
        if int(global_vocab_size) != local_vocab * world:
            raise ValueError("sparse top-p replay requires complete equal TP vocabulary shards")
        if int(vocab_start_index) != rank * local_vocab:
            raise ValueError("sparse top-p replay received a non-canonical vocabulary offset")
        self._validate_targets(
            target_ids, rows=local_logits.size(0), real_vocab_size=int(real_vocab_size)
        )

        ids = nucleus_ids.to(dtype=torch.long)
        valid = (ids >= 0) & (ids < int(real_vocab_size))
        sentinel = torch.full_like(ids, int(global_vocab_size))
        ids, _ = torch.sort(torch.where(valid, ids, sentinel), dim=1)
        valid = ids < int(real_vocab_size)
        if ids.size(1) > 1:
            valid[:, 1:] &= ids[:, 1:] != ids[:, :-1]

        local_ids = ids - int(vocab_start_index)
        owned = valid & (local_ids >= 0) & (local_ids < local_vocab)
        safe_local_ids = local_ids.clamp(0, max(local_vocab - 1, 0))
        gathered_local = local_logits.gather(1, safe_local_ids)
        gathered_local = torch.where(owned, gathered_local, torch.zeros_like(gathered_local))
        gathered = _SparseTpSum.apply(gathered_local, tp_group)
        temperature_tensor = self._temperature_tensor(
            temperature, rows=local_logits.size(0), device=local_logits.device
        )
        if temperature_tensor is None:
            temperature_tensor = torch.ones(
                (local_logits.size(0),), dtype=torch.float32, device=local_logits.device
            )
        if not isinstance(temperature, torch.Tensor):
            scalar = 1.0 if temperature is None else float(temperature)
            inverse_temperature = torch.full(
                (local_logits.size(0),),
                1.0 / scalar,
                dtype=torch.float32,
                device=local_logits.device,
            )
        else:
            # Tensor temperatures are uncommon in rollout, but keep this path
            # free of the device reciprocal intrinsic as well.  A bit-level
            # seed plus four Newton steps uses only deterministic FP32 basic
            # arithmetic.
            value = temperature_tensor.detach().contiguous()
            guess_bits = 0x7EF311C3 - value.view(torch.int32)
            inverse_temperature = guess_bits.view(torch.float32)
            for _ in range(4):
                inverse_temperature = inverse_temperature * (2.0 - value * inverse_temperature)
        result, _lse, entropy = self._canonical_sparse_nucleus_logp(
            gathered, ids, valid, target_ids.to(torch.long), inverse_temperature
        )
        self._last_provenance = {
            **self._mismatch_provenance(),
            "target": target,
            "runtime_platform": "rocm" if torch.version.hip is not None else "cuda",
            "actual_backend": self.backend_id,
            "logprob_kernel_backend": "rlkernel.sparse_nucleus.hip_serial_deterministic.v12",
            "deterministic_linear_logp": True,
            "strict_entrypoint": "sparse_nucleus_logp_from_local_logits_tp",
            "local_logits_shape": list(local_logits.shape),
            "nucleus_shape": list(nucleus_ids.shape),
            "target_shape": list(target_ids.shape),
            "tp_group_present": tp_group is not None,
            "vocab_start_index": int(vocab_start_index),
            "global_vocab_size": int(global_vocab_size),
            "real_vocab_size": int(real_vocab_size),
            "temperature": None if temperature is None else "provided",
            "contract_version": "sparse-nucleus-hip-serial-deterministic-v12",
            "logits_materialized": True,
            "lm_head_result_reused": True,
            "sparse_metric_entropy_fused": bool(return_entropy),
        }
        if return_entropy:
            return result, entropy
        return result

    def from_replicated_logits_sparse_nucleus(
        self,
        logits: torch.Tensor,
        target_ids: torch.Tensor,
        nucleus_ids: torch.Tensor,
        *,
        real_vocab_size: int,
        temperature: float,
        return_entropy: bool = False,
        tp_group: Any = None,
    ) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        """Inference-only reuse of the vocabulary already gathered by vLLM."""
        if torch.is_grad_enabled() or torch.version.hip is None:
            raise RuntimeError("replicated sparse scoring requires ROCm inference")
        if logits.ndim != 2 or logits.size(1) != real_vocab_size:
            raise ValueError("replicated sparse scoring requires the complete real vocabulary")
        if nucleus_ids.ndim != 2 or nucleus_ids.size(0) != logits.size(0):
            raise ValueError("replicated support rows must match logits")
        _, source_world = self._tp_coordinates(tp_group)
        transport_sum = source_world > 1
        if not 0 < nucleus_ids.size(1) <= 128:
            # Wider support remains exact and unrestricted; no truncation.
            return self.from_local_logits_sparse_nucleus(
                logits + 0.0 if transport_sum else logits,
                target_ids,
                nucleus_ids,
                tp_group=None,
                vocab_start_index=0,
                global_vocab_size=real_vocab_size,
                real_vocab_size=real_vocab_size,
                temperature=temperature,
                target="rollout",
                return_entropy=return_entropy,
            )
        from rl_engine.backends.extension import _C

        if temperature <= 0:
            raise ValueError("temperature must be positive")
        result, _lse, entropy, present = _C.hip_replicated_sparse_nucleus_logp(
            logits,
            nucleus_ids.to(torch.long).contiguous(),
            target_ids.to(torch.long).contiguous(),
            1.0 / float(temperature),
            transport_sum,
        )
        torch._assert_async(present.all(), "strict sparse nucleus is missing a target token")
        self._last_provenance = {
            **self._mismatch_provenance(),
            "target": "rollout",
            "runtime_platform": "rocm",
            "actual_backend": self.backend_id,
            "deterministic_linear_logp": True,
            "strict_entrypoint": "sparse_nucleus_logp_from_replicated_logits",
            "logprob_kernel_backend": "rlkernel.sparse_nucleus.hip_serial_deterministic.v12",
            "contract_version": "sparse-nucleus-hip-serial-deterministic-v12",
            "preparation_backend": "rlkernel.sparse_nucleus.hip_replicated.v1",
            "logits_materialized": True,
            "lm_head_result_reused": True,
            "replicated_logits_reused": True,
            "additional_tp_collective": False,
            "nucleus_shape": list(nucleus_ids.shape),
            "real_vocab_size": real_vocab_size,
            "temperature": "provided",
        }
        return (result, entropy) if return_entropy else result

    @classmethod
    def _validate_contract(
        cls,
        hidden: torch.Tensor,
        lm_head_weight: torch.Tensor,
        target_ids: torch.Tensor,
        bias: torch.Tensor | None,
        *,
        tp_group: Any,
        vocab_start_index: int,
        global_vocab_size: int | None,
        real_vocab_size: int | None,
    ) -> tuple[bool, int, int]:
        if hidden.ndim != 2:
            raise ValueError(
                f"linear_logp wrapper expects hidden [tokens, hidden], got {tuple(hidden.shape)}"
            )
        if not hidden.is_cuda:
            raise RuntimeError("strict linear_logp requires CUDA/ROCm GPU tensors")
        if lm_head_weight.ndim != 2:
            raise ValueError("linear_logp LM-head weight must be [vocab_local, hidden]")
        if hidden.dtype != torch.bfloat16 or lm_head_weight.dtype != torch.bfloat16:
            raise TypeError("strict linear_logp requires bfloat16 hidden and LM-head")
        if lm_head_weight.device != hidden.device:
            raise ValueError("linear_logp hidden and LM-head must share a device")
        if hidden.size(1) != lm_head_weight.size(1):
            raise ValueError("linear_logp hidden width must match LM-head width")
        if bias is not None and (
            bias.ndim != 1 or bias.size(0) != lm_head_weight.size(0) or bias.device != hidden.device
        ):
            raise ValueError("linear_logp bias must match the complete local LM-head shard")

        local_vocab = int(lm_head_weight.size(0))
        rank, world = cls._tp_coordinates(tp_group)
        tensor_parallel = tp_group is not None or int(vocab_start_index) != 0
        requested_global = (
            local_vocab * world
            if global_vocab_size is None and tensor_parallel
            else local_vocab if global_vocab_size is None else int(global_vocab_size)
        )
        if requested_global <= 0:
            raise ValueError("linear_logp global_vocab_size must be positive")
        if tensor_parallel:
            if tp_group is None:
                raise ValueError("TP linear_logp requires an explicit TP process group")
            if requested_global != local_vocab * world:
                raise ValueError(
                    "TP linear_logp requires complete equal shards: "
                    f"local={local_vocab}, world={world}, global={requested_global}"
                )
            expected_start = rank * local_vocab
            if int(vocab_start_index) != expected_start:
                raise ValueError(
                    "TP linear_logp vocab_start_index does not match rank-local shard: "
                    f"got {vocab_start_index}, expected {expected_start}"
                )
        elif requested_global != local_vocab or int(vocab_start_index) != 0:
            raise ValueError("non-TP linear_logp must use the complete local vocab at offset zero")
        real = requested_global if real_vocab_size is None else int(real_vocab_size)
        if real <= 0 or real > requested_global:
            raise ValueError(
                f"linear_logp real_vocab_size must be in [1, {requested_global}], got {real}"
            )
        cls._validate_targets(target_ids, rows=hidden.size(0), real_vocab_size=real)
        return tensor_parallel, requested_global, real

    @staticmethod
    def _rocm_contract(
        local_logits: torch.Tensor,
        *,
        rank: int,
        world: int,
        global_vocab_size: int,
        real_vocab_size: int,
        target: str,
    ) -> LogprobContract:
        local_vocab = int(local_logits.size(1))
        dtype = {
            torch.bfloat16: LogprobDType.BF16,
            torch.float16: LogprobDType.FP16,
            torch.float32: LogprobDType.FP32,
        }.get(local_logits.dtype)
        if dtype is None:
            raise TypeError(f"unsupported ROCm linear_logp dtype {local_logits.dtype}")
        role = LogprobRole.TRAIN if target == "training" else LogprobRole.INFER
        return LogprobContract(
            role=role,
            dtype=dtype,
            mask=MaskSpec(
                num_tokens=int(local_logits.size(0)),
                active_mask=(True,) * int(local_logits.size(0)),
            ),
            sharding=ShardingSpec(
                tp_rank=rank,
                tp_world_size=world,
                vocab_shard_bounds=tuple(
                    (index * local_vocab, (index + 1) * local_vocab) for index in range(world)
                ),
                real_vocab_size=real_vocab_size,
                padded_vocab_size=global_vocab_size,
            ),
            reduction=ReductionSpec(),
        )

    def _rocm_from_local_logits(
        self,
        local_logits: torch.Tensor,
        target_ids: torch.Tensor,
        *,
        tp_group: Any,
        rank: int,
        world: int,
        global_vocab_size: int,
        real_vocab_size: int,
        target: str,
        temperature: float | torch.Tensor | None,
        diagnostics_hidden: torch.Tensor | None = None,
        diagnostics_lm_head_weight: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, str]:
        if temperature is None or (
            not isinstance(temperature, torch.Tensor) and float(temperature) == 1.0
        ):
            effective_logits = local_logits.contiguous()
            # Megatron exposes the materialized TP LM-head through a squeezed
            # view.  The loss path may reuse that storage while autograd still
            # needs it for the logp backward.  Keep one gradient-preserving
            # snapshot for the strict training kernel; rollout is inference
            # only and remains zero-copy.
            if target == "training" and effective_logits.requires_grad:
                effective_logits = effective_logits.clone()
        else:
            temperature_tensor = self._temperature_tensor(
                temperature,
                rows=local_logits.size(0),
                device=local_logits.device,
            )
            assert temperature_tensor is not None
            # VIME scales a global temperature with PyTorch scalar division.
            # Tensor division has different FP32 rounding on ROCm; preserve
            # the same arithmetic when the request carries a scalar value.
            divisor = (
                temperature_tensor.unsqueeze(1)
                if isinstance(temperature, torch.Tensor)
                else float(temperature)
            )
            effective_logits = local_logits.float() / divisor
        contract = self._rocm_contract(
            effective_logits,
            rank=rank,
            world=world,
            global_vocab_size=global_vocab_size,
            real_vocab_size=real_vocab_size,
            target=target,
        )
        op = self._resolve_rocm()
        result, lse = op.apply(
            effective_logits,
            target_ids,
            contract=contract,
            tp_group=tp_group,
            num_vocab_tiles=DEFAULT_NUM_VOCAB_TILES,
            deterministic=True,
            targets_validated=True,
            cache_preflight=target == "rollout",
        )
        _record_alignment_diagnostics(
            target=target,
            local_logits=effective_logits,
            target_ids=target_ids,
            result=result,
            lse=lse,
            vocab_start_index=rank * int(effective_logits.size(1)),
            hidden=diagnostics_hidden,
            lm_head_weight=diagnostics_lm_head_weight,
        )
        return result, lse, str(op.backend_id)

    def from_local_logits(
        self,
        local_logits: torch.Tensor,
        target_ids: torch.Tensor,
        *,
        tp_group: Any,
        vocab_start_index: int,
        global_vocab_size: int,
        real_vocab_size: int,
        target: str = "rollout",
        temperature: float | torch.Tensor | None = None,
        return_lse: bool = False,
        diagnostics_hidden: torch.Tensor | None = None,
        diagnostics_lm_head_weight: torch.Tensor | None = None,
    ) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        """Score deterministic local LM-head logits without a duplicate GEMM."""

        if local_logits.ndim != 2 or local_logits.dtype not in (
            torch.bfloat16,
            torch.float16,
            torch.float32,
        ):
            raise TypeError("strict reused LM-head logits must be 2-D bf16/fp16/fp32")
        if not local_logits.is_cuda:
            raise RuntimeError("strict reused LM-head logits require CUDA/ROCm")
        if target_ids.device != local_logits.device:
            raise ValueError("linear_logp target_ids must share the logits device")
        rank, world = self._tp_coordinates(tp_group)
        local_vocab = int(local_logits.size(1))
        requested_global = int(global_vocab_size)
        expected_global = local_vocab * world
        expected_start = rank * local_vocab
        if requested_global != expected_global or int(vocab_start_index) != expected_start:
            raise ValueError("reused rollout LM-head logits must use equal rank-ordered TP shards")
        real = int(real_vocab_size)
        if not 0 < real <= requested_global:
            raise ValueError("real_vocab_size must be within the padded global vocabulary")
        self._validate_targets(
            target_ids,
            rows=local_logits.size(0),
            real_vocab_size=real,
        )
        if torch.version.hip is not None:
            result, lse, kernel_backend = self._rocm_from_local_logits(
                local_logits,
                target_ids,
                tp_group=tp_group,
                rank=rank,
                world=world,
                global_vocab_size=requested_global,
                real_vocab_size=real,
                target=target,
                temperature=temperature,
                diagnostics_hidden=diagnostics_hidden,
                diagnostics_lm_head_weight=diagnostics_lm_head_weight,
            )
            runtime_platform = "rocm"
            strict_entrypoint = (
                "rocm_deterministic_linear_logp_tp"
                if target == "training"
                else "rocm_vocab_parallel_logp_from_local_logits_tp"
            )
            contract_version = "rocm-det-gemm-vocab-parallel-logp-ws2-v1"
        else:
            temperature_tensor = self._temperature_tensor(
                temperature,
                rows=local_logits.size(0),
                device=local_logits.device,
            )
            from rl_engine.backends.cuda.logprob.linear_logp import (
                sm90_deterministic_logp_from_local_logits_tp,
            )

            result, lse = sm90_deterministic_logp_from_local_logits_tp(
                local_logits.contiguous(),
                target_ids,
                tp_group=tp_group,
                vocab_start_index=int(vocab_start_index),
                global_vocab_size=requested_global,
                real_vocab_size=real,
                temperature=temperature_tensor,
            )
            kernel_backend = self.backend_id
            runtime_platform = "cuda"
            strict_entrypoint = "sm90_deterministic_logp_from_local_logits_tp"
            contract_version = "cuda-det-gemm-linear-logp-sm90-contract-v2"
        self._last_provenance = {
            **self._mismatch_provenance(),
            "target": target,
            "runtime_platform": runtime_platform,
            "triton_used": runtime_platform == "rocm",
            "actual_backend": self.backend_id,
            "logprob_kernel_backend": kernel_backend,
            "deterministic_linear_logp": True,
            "strict_entrypoint": strict_entrypoint,
            "local_logits_shape": list(local_logits.shape),
            "target_shape": list(target_ids.shape),
            "tp_group_present": True,
            "vocab_start_index": int(vocab_start_index),
            "global_vocab_size": requested_global,
            "real_vocab_size": real,
            "temperature": None if temperature is None else "provided",
            "contract_version": contract_version,
            "logits_materialized": True,
            "lm_head_result_reused": True,
        }
        return (result, lse) if return_lse else result

    def from_local_logits_top_p(
        self,
        local_logits: torch.Tensor,
        target_ids: torch.Tensor,
        replay_ids: torch.Tensor,
        replay_logprobs: torch.Tensor,
        *,
        tp_group: Any,
        vocab_start_index: int,
        global_vocab_size: int,
        real_vocab_size: int,
        target: str = "rollout",
        temperature: float | torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Score compact rollout top-p support without a full-vocab replay mask."""

        if local_logits.ndim != 2 or local_logits.dtype != torch.bfloat16:
            raise TypeError("strict reused LM-head logits must be 2-D bfloat16")
        if not local_logits.is_cuda:
            raise RuntimeError("strict reused LM-head logits require CUDA/ROCm")
        if torch.version.hip is not None:
            if replay_ids.shape != replay_logprobs.shape or replay_ids.size(0) != local_logits.size(
                0
            ):
                raise ValueError("top-p support must match the local-logit rows")
            # The sampler transports every retained ID. Integer accumulation
            # preserves membership when the sampled token also appears in topk.
            ids = replay_ids.to(device=local_logits.device, dtype=torch.long)
            retained = torch.isfinite(replay_logprobs)
            local_ids = ids - int(vocab_start_index)
            owned = retained & (local_ids >= 0) & (local_ids < local_logits.size(1))
            counts = torch.zeros_like(local_logits, dtype=torch.int32)
            counts.scatter_add_(
                1, local_ids.clamp(0, local_logits.size(1) - 1), owned.to(torch.int32)
            )
            masked = local_logits.masked_fill(counts == 0, float("-inf"))
            result = self.from_local_logits(
                masked,
                target_ids,
                tp_group=tp_group,
                vocab_start_index=vocab_start_index,
                global_vocab_size=global_vocab_size,
                real_vocab_size=real_vocab_size,
                target=target,
                temperature=temperature,
            )
            self._last_provenance["top_p_replay"] = True
            self._last_provenance["top_p_support"] = "complete_sampler_retained_ids"
            return result
        rank, world = self._tp_coordinates(tp_group)
        if tp_group is None or world <= 1:
            raise ValueError("reused rollout LM-head logits require a multi-rank TP group")
        local_vocab = int(local_logits.size(1))
        requested_global = int(global_vocab_size)
        if requested_global != local_vocab * world:
            raise ValueError("reused rollout LM-head logits must use equal TP shards")
        if int(vocab_start_index) != rank * local_vocab:
            raise ValueError("reused rollout LM-head logits use a wrong TP shard offset")
        real = int(real_vocab_size)
        if not 0 < real <= requested_global:
            raise ValueError("real_vocab_size must be within the padded global vocabulary")
        self._validate_targets(target_ids, rows=local_logits.size(0), real_vocab_size=real)
        temperature_tensor = self._temperature_tensor(
            temperature, rows=local_logits.size(0), device=local_logits.device
        )
        from rl_engine.backends.cuda.logprob.linear_logp import (
            sm90_deterministic_top_p_logp_from_local_logits_tp,
        )

        result, _lse = sm90_deterministic_top_p_logp_from_local_logits_tp(
            local_logits.contiguous(),
            target_ids,
            replay_ids,
            replay_logprobs,
            tp_group=tp_group,
            vocab_start_index=int(vocab_start_index),
            global_vocab_size=requested_global,
            real_vocab_size=real,
            temperature=temperature_tensor,
        )
        self._last_provenance = {
            **self._mismatch_provenance(),
            "target": target,
            "runtime_platform": "cuda",
            "triton_used": False,
            "actual_backend": self.backend_id,
            "deterministic_linear_logp": True,
            "strict_entrypoint": "sm90_deterministic_top_p_logp_from_local_logits_tp",
            "local_logits_shape": list(local_logits.shape),
            "replay_shape": list(replay_ids.shape),
            "tp_group_present": True,
            "vocab_start_index": int(vocab_start_index),
            "global_vocab_size": requested_global,
            "real_vocab_size": real,
            "temperature": None if temperature is None else "provided",
            "contract_version": "cuda-det-gemm-linear-logp-sm90-top-p-sparse-v1",
            "logits_materialized": True,
            "lm_head_result_reused": True,
            "top_p_replay": True,
        }
        return result

    @staticmethod
    def _mismatch_provenance() -> dict[str, Any]:
        case_id = os.getenv("RL_KERNEL_LOGP_CASE", "P/P").strip().upper()
        case = operator_ablation_case("logp", case_id)
        cross_engine_mismatch = case.training is not case.rollout
        return {
            "module": "logp",
            "case_id": case.case_id,
            "training_implementation": case.training.value,
            "rollout_implementation": case.rollout.value,
            "mismatch_axes": {
                # PR230 L1-L3 axes. R/R closes all of them by sharing the
                # padded TP LM-head and the rank-ordered LSE merge.
                "vocab_shard_ownership": cross_engine_mismatch,
                "selected_token_identity": cross_engine_mismatch,
                "vocab_lse_reduction": cross_engine_mismatch,
            },
            "arithmetic_contract": {
                "batch_invariant": True,
                "fixed_k_reduction": True,
                "vocab_group_width": 64,
                "summary_merge_tree": "rank_ordered_fixed",
                "vocab_reduction_axis": "TP",
                "cp_is_merge_axis": False,
                "output_dtype": "fp32",
            },
        }

    def __call__(
        self,
        hidden: torch.Tensor,
        lm_head_weight: torch.Tensor,
        target_ids: torch.Tensor,
        bias: torch.Tensor | None = None,
        *,
        tp_group: Any = None,
        vocab_start_index: int = 0,
        global_vocab_size: int | None = None,
        real_vocab_size: int | None = None,
        target: str = "training",
        temperature: float | torch.Tensor | None = None,
    ) -> torch.Tensor:
        if target_ids.device != hidden.device:
            raise ValueError("linear_logp target_ids must share hidden device")
        tensor_parallel, requested_global_vocab, real = self._validate_contract(
            hidden,
            lm_head_weight,
            target_ids,
            bias,
            tp_group=tp_group,
            vocab_start_index=int(vocab_start_index),
            global_vocab_size=global_vocab_size,
            real_vocab_size=real_vocab_size,
        )
        effective_weight = lm_head_weight
        effective_bias = bias
        if torch.version.hip is not None:
            local_logits = self._resolve_rocm_linear().linear(hidden, effective_weight)
            if effective_bias is not None:
                local_logits = local_logits + effective_bias
            result, _lse, kernel_backend = self._rocm_from_local_logits(
                local_logits,
                target_ids,
                tp_group=tp_group,
                rank=self._tp_coordinates(tp_group)[0],
                world=self._tp_coordinates(tp_group)[1],
                global_vocab_size=requested_global_vocab,
                real_vocab_size=real,
                target=target,
                temperature=temperature,
                diagnostics_hidden=hidden,
                diagnostics_lm_head_weight=effective_weight,
            )
            runtime_platform = "rocm"
            strict_entrypoint = "rocm_deterministic_linear_logp_tp"
            contract_version = "rocm-det-gemm-vocab-parallel-logp-ws2-v1"
        else:
            temperature_tensor = self._temperature_tensor(
                temperature, rows=hidden.size(0), device=hidden.device
            )
            op = self._resolve(tensor_parallel=tensor_parallel)
            if tensor_parallel:
                result, _lse = op(
                    hidden,
                    effective_weight,
                    target_ids,
                    effective_bias,
                    tp_group=tp_group,
                    vocab_start_index=int(vocab_start_index),
                    global_vocab_size=requested_global_vocab,
                    real_vocab_size=real,
                    temperature=temperature_tensor,
                )
            else:
                result, _lse = op(
                    hidden,
                    effective_weight,
                    target_ids,
                    effective_bias,
                    real_vocab_size=real,
                    temperature=temperature_tensor,
                )
            kernel_backend = self.backend_id
            runtime_platform = "cuda"
            strict_entrypoint = (
                "sm90_deterministic_linear_logp_tp"
                if tensor_parallel
                else "sm90_deterministic_linear_logp"
            )
            contract_version = "cuda-det-gemm-linear-logp-sm90-contract-v2"
        if not isinstance(result, torch.Tensor):
            raise RuntimeError("linear_logp backend returned a non-tensor result")
        if result.numel() != hidden.size(0):
            raise RuntimeError(
                "linear_logp backend returned an unexpected token count: "
                f"{result.numel()} != {hidden.size(0)}"
            )

        actual_backend = self.backend_id
        self._last_provenance = {
            **self._mismatch_provenance(),
            "target": target,
            "runtime_platform": runtime_platform,
            "triton_used": runtime_platform == "rocm",
            "actual_backend": actual_backend,
            "logprob_kernel_backend": kernel_backend,
            "deterministic_linear_logp": True,
            "strict_entrypoint": strict_entrypoint,
            "hidden_shape": list(hidden.shape),
            "hidden_dtype": str(hidden.dtype).replace("torch.", ""),
            "lm_head_weight_shape": list(lm_head_weight.shape),
            "target_shape": list(target_ids.shape),
            "tp_group_present": tp_group is not None,
            "vocab_start_index": int(vocab_start_index),
            "global_vocab_size": requested_global_vocab,
            "requested_global_vocab_size": requested_global_vocab,
            "real_vocab_size": real,
            "requested_real_vocab_size": None if real_vocab_size is None else int(real_vocab_size),
            "temperature": None if temperature is None else "provided",
            "contract_version": contract_version,
            "logits_materialized": True,
        }
        return result


__all__ = [
    "LinearLogpWrapper",
    "RolloutLinearLogpContext",
    "clear_rollout_linear_logp_context",
    "publish_rollout_linear_logp_context",
    "take_rollout_linear_logp_context",
]
